PARSE NETWORK STATS


What is it?
-----------
A java application that parses multiple network statistics outputs into a more readable form.
It can output in .txt, .csv or .json.


Latest Version
--------------
The latest version can be found at https://github.com/MarkNKamau/ParseNetworkStats/releases


Installation
------------
The application does not need to be installed. 
Run using ParseNetStats.jar
*gson-2.8.0.jar needs to be in the same folder as ParseNetStats.jar


How to use
----------
1. Prepare a text file of network statistics formatted as...

	Ping statistics for x.x.x.x:  
	   Packets: Sent = x, Received = x, Lost = x (x% loss),  
	Approximate round trip times in milli-seconds:`  
	   Minimum = x ms, Maximum = x ms, Average = x ms

	Any part not formatted as such will produce an error be skiped. However, it may still cause errors in the output.

2. Select the appropriate locations and names of files.

	Output folder may be left blank.

3. Select the preferred output formats.

	If no output format is selected, a preview of the data will still be given.


Licenses
--------
This application is licensed under Apache 2.0 License.


Contacts
--------
Mark Njung'e Kamau - Developer
mark.kamau@Outlook.com


Bug Reporting
-------------
Please report any bugs to https://github.com/MarkNKamau/ParseNetworkStats/issues


Source code
-----------
The source code can be found at https://github.com/MarkNKamau/ParseNetworkStats
